
import SwiftUI
import LocalAuthentication


// MARK: - Data Models
struct Note: Identifiable, Codable {
    let id: UUID
    var title: String
    var description: String
    var time: String
    var backgroundColor: ColorData
    var tags: [String]
    var isLocked: Bool
}

struct ColorData: Codable {
    let red: Double
    let green: Double
    let blue: Double
    let opacity: Double

    init(color: Color) {
        let components = color.cgColor?.components ?? [0, 0, 0, 1]
        self.red = Double(components[0])
        self.green = Double(components[1])
        self.blue = Double(components[2])
        self.opacity = Double(components[3])
    }

    func toColor() -> Color {
        Color(red: red, green: green, blue: blue, opacity: opacity)
    }
}

// MARK: - Main View
struct ContentView: View {
    @State private var notes: [Note] = []
    @State private var showingAddNote = false
    @State private var searchText = ""
    @State private var selectedNote: Note? = nil
    @State private var isEditingNote = false
    @State private var noteToDelete: Note? = nil
    @State private var showingDeleteAlert = false
    @State private var sortOption: SortOption = .title
    @State private var showOnboarding = !UserDefaults.standard.bool(forKey: "hasShownOnboarding")
    @Environment(\.colorScheme) var colorScheme

    let columns = [GridItem(.flexible()), GridItem(.flexible())]

    enum SortOption: String, CaseIterable {
        case title = "Title"
        case time = "Time"
        case color = "Color"
    }

    var filteredNotes: [Note] {
        if searchText.isEmpty {
            return notes
        } else {
            return notes.filter {
                $0.title.localizedCaseInsensitiveContains(searchText) ||
                $0.description.localizedCaseInsensitiveContains(searchText) ||
                $0.tags.contains { $0.localizedCaseInsensitiveContains(searchText) }
            }
        }
    }

    var sortedNotes: [Note] {
        switch sortOption {
        case .title:
            return filteredNotes.sorted { $0.title < $1.title }
        case .time:
            return filteredNotes.sorted { $0.time < $1.time }
        case .color:
            return filteredNotes.sorted { $0.backgroundColor.toColor().description < $1.backgroundColor.toColor().description }
        }
    }

    var body: some View {
        NavigationView {
            VStack {
                // Search Bar
                SearchBar(searchText: $searchText)

                // Sorting Picker
                SortPicker(sortOption: $sortOption)

                // Notes Grid
                if sortedNotes.isEmpty {
                    Text("No notes available. Tap the + button to add a new note!")
                        .font(.headline)
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                        .padding()
                } else {
                    ScrollView {
                        LazyVGrid(columns: columns, spacing: 20) {
                            ForEach(sortedNotes) { note in
                                NoteCard(note: note) {
                                    selectedNote = note
                                    isEditingNote = true
                                } onLongPress: {
                                    noteToDelete = note
                                    showingDeleteAlert = true
                                }
                            }
                        }
                        .padding()
                    }
                }

                Spacer()

                // Add Note Button
                Button(action: {
                    showingAddNote = true
                }) {
                    Image(systemName: "plus")
                        .font(.system(size: 30))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.orange)
                        .clipShape(Circle())
                        .shadow(radius: 5)
                }
                .padding(.bottom, 20)
            }
            .navigationTitle("Notes")
            .onAppear(perform: loadNotes)
            .sheet(isPresented: $showingAddNote) {
                AddNoteView { newNote in
                    notes.append(newNote)
                    saveNotes()
                }
            }
            .sheet(item: $selectedNote) { note in
                EditNoteView(note: note) { updatedNote in
                    if let index = notes.firstIndex(where: { $0.id == updatedNote.id }) {
                        notes[index] = updatedNote
                        saveNotes()
                    }
                }
            }
            .alert(isPresented: $showingDeleteAlert) {
                Alert(
                    title: Text("Delete Note"),
                    message: Text("Are you sure you want to delete this note?"),
                    primaryButton: .destructive(Text("Delete")) {
                        if let noteToDelete = noteToDelete,
                           let index = notes.firstIndex(where: { $0.id == noteToDelete.id }) {
                            notes.remove(at: index)
                            saveNotes()
                        }
                    },
                    secondaryButton: .cancel()
                )
            }
            .sheet(isPresented: $showOnboarding) {
                OnboardingView {
                    UserDefaults.standard.set(true, forKey: "hasShownOnboarding")
                    showOnboarding = false
                }
            }
            .background(colorScheme == .dark ? Color.black : Color.white)
        }
    }

    // Save and Load Notes
    func saveNotes() {
        if let encoded = try? JSONEncoder().encode(notes) {
            UserDefaults.standard.set(encoded, forKey: "SavedNotes")
        }
    }

    func loadNotes() {
        if let savedNotes = UserDefaults.standard.data(forKey: "SavedNotes"),
           let decodedNotes = try? JSONDecoder().decode([Note].self, from: savedNotes) {
            self.notes = decodedNotes
        }
    }
}

// MARK: - Note Card View
struct NoteCard: View {
    let note: Note
    var onTap: () -> Void
    var onLongPress: () -> Void

    var body: some View {
        VStack(alignment: .leading) {
            Text(note.title)
                .font(.headline)
                .foregroundColor(.white)
            Text(note.description)
                .font(.subheadline)
                .foregroundColor(.white.opacity(0.9))
            Spacer()
            Text(note.time)
                .font(.caption)
                .foregroundColor(.white.opacity(0.7))
                .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .padding()
        .background(note.backgroundColor.toColor())
        .cornerRadius(15)
        .shadow(color: .gray, radius: 5, x: 0, y: 5)
        .onTapGesture(perform: onTap)
        .onLongPressGesture(perform: onLongPress)
    }
}

// MARK: - Search Bar View
struct SearchBar: View {
    @Binding var searchText: String

    var body: some View {
        TextField("Search notes...", text: $searchText)
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding(.horizontal)
    }
}

// MARK: - Sort Picker View
struct SortPicker: View {
    @Binding var sortOption: ContentView.SortOption

    var body: some View {
        Picker("Sort By", selection: $sortOption) {
            ForEach(ContentView.SortOption.allCases, id: \.self) { option in
                Text(option.rawValue)
            }
        }
        .pickerStyle(SegmentedPickerStyle())
        .padding(.horizontal)
    }
}

// MARK: - Onboarding View
struct OnboardingView: View {
    var onDismiss: () -> Void

    var body: some View {
        VStack {
            Text("Pendown")
                .font(.largeTitle)
                .padding()
            Text("Bring your ideas to life—one stroke at a time!")
                .font(.headline)
                .multilineTextAlignment(.center)
                .padding()
            Button("Get Started") {
                onDismiss()
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .padding()
    }
}

// MARK: - Add Note View
struct AddNoteView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var title = ""
    @State private var description = ""
    @State private var backgroundColor = Color.blue
    @State private var tags = ""
    @State private var isLocked = false

    var onSave: (Note) -> Void

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Title")) {
                    TextField("Enter title", text: $title)
                }
                Section(header: Text("Description")) {
                    TextEditor(text: $description)
                        .frame(height: 200)
                }
                Section(header: Text("Tags")) {
                    TextField("Add tags (comma separated)", text: $tags)
                }
                Section(header: Text("Background Color")) {
                    ColorPicker("Choose color", selection: $backgroundColor)
                }
                Section {
                    Toggle("Lock Note", isOn: $isLocked)
                }
            }
            .navigationTitle("Add Note")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        let newNote = Note(
                            id: UUID(),
                            title: title.isEmpty ? "Untitled" : title,
                            description: description.isEmpty ? "No description" : description,
                            time: DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .short),
                            backgroundColor: ColorData(color: backgroundColor),
                            tags: tags.components(separatedBy: ",").map { $0.trimmingCharacters(in: .whitespaces) },
                            isLocked: isLocked
                        )
                        onSave(newNote)
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Edit Note View
struct EditNoteView: View {
    @Environment(\.presentationMode) var presentationMode
    @State var note: Note
    var onSave: (Note) -> Void

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Title")) {
                    TextField("Edit title", text: $note.title)
                }
                Section(header: Text("Description")) {
                    TextEditor(text: $note.description)
                        .frame(height: 200)
                }
                Section(header: Text("Tags")) {
                    TextField("Edit tags (comma separated)", text: .constant(note.tags.joined(separator: ", ")))
                }
                Section(header: Text("Background Color")) {
                    ColorPicker("Change color", selection: Binding(
                        get: { note.backgroundColor.toColor() },
                        set: { newColor in note.backgroundColor = ColorData(color: newColor) }
                    ))
                }
                Section {
                    Toggle("Lock Note", isOn: $note.isLocked)
                }
            }
            .navigationTitle("Edit Note")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        onSave(note)
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



























